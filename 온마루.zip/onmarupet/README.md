# 온마루펫

Firebase + Stripe + Next.js 기반 반려동물 간식 정기배송 플랫폼

## 실행 방법
```bash
npm install
npm run dev
```

## 환경변수 설정
`.env.local` 파일에 `.env.example` 내용 복사 후 실제 키 입력