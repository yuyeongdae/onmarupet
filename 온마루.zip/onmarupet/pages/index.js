export default function Home() {
  return (
    <div style={{ padding: 40, fontFamily: 'sans-serif', textAlign: 'center' }}>
      <h1>온마루펫</h1>
      <p>장어 부산물로 만든 프리미엄 반려견 간식, 정기배송 플랫폼</p>
    </div>
  );
}