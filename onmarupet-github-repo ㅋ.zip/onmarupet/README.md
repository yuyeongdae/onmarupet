# 온마루펫

프리미엄 반려동물 간식 정기배송 플랫폼

## 실행 방법
```bash
npm install
npm run dev
```

## 환경 변수
- `.env.example` 참고하여 `.env.local` 작성
- Firebase, Stripe 설정 필요

## 배포
Vercel에 GitHub 저장소 연결 후 배포
